+++
title = "Example Page"

date = 2018-09-09T00:00:00
# lastmod = 2018-09-09T00:00:00

draft = false  # Is this a draft? true/false
toc = true  # Show table of contents? true/false
type = "docs"  # Do not modify.

# Add menu entry to sidebar.
linktitle = "Example Page"
[menu.tutorial]
  parent = "Example Topic"
  weight = 1
+++

In this tutorial, I'll share my top 10 tips for getting started with Academic:

## Tip 1

...

## Tip 2

...
